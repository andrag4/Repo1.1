WINMERGE

WinMerge � um utilit�rio de compara��o e uni�o de arquivos com o c�digo fonte aberto o qual roda em todas as vers�es modernas do windows. Algumas fun��es requerem instala��es ou componentes adicionais. A �ltima vers�o do WinMerge e outras informa��es do WinMerge est�o dispon�veis em 
http://winmerge.org

 In�cio r�pido para o WinMerge: Leia o cap�tulo do in�cio r�pido do manual online para se iniciar com o WinMerge:
 http://manual.winmerge.org/QuickStart.html

 Manual em HTML: O manual est� dispon�vel online em 
http://manual.winmerge.org/ ele est� tamb�m possivelmente instalado (se escolhido assim) localmente e descarreg�vel separadamente de http://winmerge.org/ (veja a documenta��o) Suporte para Arquivos: O 
WinMerge usa o 7-Zip para o suporte para arquivos dentro de arquivos. 7-Zip (http://www.7-zip.org) � uma ferramenta para arquivos com o c�digo fonte aberto. Para instalar o suporte para arquivos dentro de arquivos, baixe o instalador do plugin do 7-Zip de http://winmerge.org/ 

Instalando o suporte para arquivos: � recomendado instalar o aplicativo 7-Zip. Se isto n�o pode ser feito por alguma raz�o, o instalador do plugin do 7-Zip pode instalar apenas os arquivos necess�rios para ativar o suporte para arquivos dentro dos arquivos. Note que N�O permite o uso isolado do 7-Zip, apenas o suporte para arquivos para oWinMerge.

 Suporte a Scripts:
 Se voc� gostaria de trabalhar com scripts Voc� precisar� ter o Windows 
Scripting Host instalado. Se voc� receber quaisquer erros relacionados aos seus 
scripts por favor visite 
http://msdn.microsoft.com/library/default.asp?url=/downloads/list/webdev.asp
 para ter certeza que seu Scripting Host est� ambos atualizado e n�o corrompido. 

Suporte:
 Os desenvolvedores est�o respondendo as quest�es nos f�runs do WinMerge em Sourceforge.net:
http://sourceforge.net/forum/?group_id=13216
 
Bugs e pedidos para fun��es: 
Bugs e sugest�es para novas fun��es devem ser submetidos nos trackers dos bugs e pedidos para fun��es no sourceforge.net.
 
Bug tracker:
http://sourceforge.net/tracker/?group_id=13216&atid=113216 quando reportando um bug, por favor nos diga o n�mero da vers�o do WinMerge! As vers�es do 
WinMerge2.2.0 e posterior podem emitir um 'Log da Configura��o' no 
menu Ajuda/Configura��o. Por favor anexe esta info (como anexo do arquivo) ao relat�rio sobre o bug, ele tem muita informa��o �til para os desenvolvedores. 
Tracker 
RFE (pedido para fun��es):
 http://sourceforge.net/tracker/?group_id=13216&atid=363216


- Os Desenvolvedores do WinMerge
